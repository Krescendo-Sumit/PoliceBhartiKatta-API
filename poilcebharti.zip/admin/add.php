<?php
session_start();
$fname=$_SESSION['ufilename'];
   echo "Hello".$fname;


?>

