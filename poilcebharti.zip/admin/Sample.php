<?php

 include './start.php';
 include './headermenu.php';
 include './leftslidermenu.php';
 include './pagecontent.php';
 include './end.php';

?>