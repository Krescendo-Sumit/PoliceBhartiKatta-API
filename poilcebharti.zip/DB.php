<?php
date_default_timezone_set("Asia/Kolkata");

$con=mysqli_connect("localhost","root","","db_policebharti");
?>