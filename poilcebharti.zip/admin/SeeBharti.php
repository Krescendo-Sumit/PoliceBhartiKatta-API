

<?php

 include './start.php';
 include './headermenu.php';
 include './leftslidermenu.php';
 include './content/seeBharti.php';
 include './end.php';

?>