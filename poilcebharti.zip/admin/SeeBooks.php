

<?php

include './start.php';
include './headermenu.php';
include './leftslidermenu.php';
include './content/seeBooks.php';
include './end.php';
?>